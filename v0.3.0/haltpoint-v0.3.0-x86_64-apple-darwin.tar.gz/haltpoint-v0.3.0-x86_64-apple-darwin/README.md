# Haltpoint

Debug probe tooling that tells you **why** your target won't connect, and what to do about it.

```
$ haltpoint doctor
  --  Using settings from /work/blinky/haltpoint.toml
  ok  Probe opened: STLink V3 -- 0483:374e:004600373335510235383531 (ST-LINK)
  --  ST-Link firmware V3J18
  ok  Target powered (3.26 V)
  ok  Debug port responds over SWD at 4000 kHz
WARN  USB link dropped at 4000 kHz, worked when retried at 1000 kHz
       -> If this keeps happening, add `speed_khz = 1000` to haltpoint.toml.
       -> Try a shorter or better USB cable.
  ok  Chip identified: STM32H753ZI (1 core)
```

When something is wrong, it says so in plain words:

```
FAIL  The probe is in use by openocd (pid 30482)
       STLink V3 -- 0483:374e:... is open in another program, so haltpoint can't use it.
       -> Stop that program's debug session or close it, then run haltpoint again.
```

Haltpoint is built on [probe-rs](https://probe.rs), so it works with the probes you already own:
ST-Link, J-Link, CMSIS-DAP (DAPLink, Raspberry Pi Debug Probe, MCU-Link), FTDI and more, on
Linux, macOS and Windows.

> **Status:** early release. Tested on our bench with a J-Link on an ATSAM4E16C (flashing a
> customer's product image), the nRF5340 DK's on-board J-Link, and a NUCLEO-H753ZI's
> ST-Link V3. Other probe and chip combinations should work through probe-rs but haven't been
> tested yet. Reports of what works and what doesn't are very welcome.

## Quick start

1. **Download Haltpoint** from the [downloads page](https://github.com/haltpoint/downloads):
   one archive each for Linux (x86-64, and arm64 or 32-bit Arm for a Raspberry Pi), macOS (Apple
   silicon or Intel) and Windows. Unpack it and put `haltpoint` on your PATH. On Debian, Ubuntu
   or Raspberry Pi OS, the `.deb` package (`sudo apt install ./haltpoint_*.deb`) also sets up
   USB access for common probes. The Linux builds run on any distribution with glibc 2.28 or
   later (Debian 10, Ubuntu 18.10, RHEL 8 and newer).

   The macOS and Windows builds aren't signed yet. If macOS refuses to run `haltpoint`, clear the
   download flag once with `xattr -d com.apple.quarantine /usr/local/bin/haltpoint` (or wherever
   you put it). Windows SmartScreen may warn the first time; choose "Run anyway".

   On Linux without the `.deb`, also install the
   [probe-rs udev rules](https://probe.rs/docs/getting-started/probe-setup/) so you can use
   probes without root.

2. **Plug in your probe and board**, then check the connection:

   ```
   haltpoint doctor
   ```

   If it can't identify the chip, look up its name and pass it in:

   ```
   haltpoint chips stm32h7
   haltpoint doctor --chip STM32H753ZI
   ```

3. **Save your settings** in a `haltpoint.toml` at the root of your firmware project, so you don't
   have to repeat flags:

   ```toml
   chip = "STM32H753ZI"
   ```

   Doctor will tell you if you need anything else in there, for example a lower speed.

4. **See your firmware's output** over SWO. Pass the core clock your firmware runs at:

   ```
   haltpoint swo --clock-hz 64000000 --self-test   # check the SWO path works
   haltpoint swo --clock-hz 64000000               # print ITM output until Ctrl+C
   ```

## Commands

| Command | What it does |
|---|---|
| `haltpoint doctor` | Checks the probe, target power, the SWD/JTAG link at falling speeds, chip identification and connect-under-reset, then explains what's wrong and how to fix it. Exits with status 1 if anything failed. `--json` prints the findings as JSON for scripts and CI: `{"result": "Fail", "findings": [{"severity", "title", "detail", "fixes"}, ...]}`, where `result` is the worst severity (`Ok`, `Info`, `Warn` or `Fail`). |
| `haltpoint swo --clock-hz HZ` | Prints what firmware writes to the ITM stimulus ports over SWO: port 0 as text, other ports with a `[port N]` prefix. `--self-test` checks the SWO path with no firmware support. `swo` and `rtt` both take `--timestamps`, `--grep TEXT` to show only matching lines, and `--log FILE` to keep every line. |
| `haltpoint reset` | Resets the target and lets it run; `--halt` stops it at the first instruction and prints where. With `--remote URL` it resets a board on a `haltpoint serve` server (users need the `flash` permission). |
| `haltpoint vscode build/app.elf` | Writes `.vscode/launch.json` and `tasks.json` for the Cortex-Debug extension, so F5 flashes the firmware with haltpoint, starts `haltpoint gdb` and stops at `main`. Works for C, C++ and Rust; `--remote URL` debugs a board on a remote server. Needs `arm-none-eabi-gdb` on the PATH. `--print` shows the files without writing them. |
| `haltpoint rtt` | Prints what firmware writes over SEGGER RTT while it runs, and sends lines you type to down channel 0. `--elf FILE` finds the control block at once instead of searching RAM, and decodes defmt logs (with source lines when the ELF has debug info). With several channels each line is prefixed with its channel's name. With `--remote URL`, reads RTT from a board on a remote `haltpoint serve` ([docs/remote.md](docs/remote.md#rtt)). |
| `haltpoint test app.elf --pass "ALL TESTS PASSED" --fail FAIL` | For CI on real hardware: flashes test firmware, shows its RTT output (or a serial port's, with `--uart /dev/ttyACM0 --baud 115200`), and exits 0 when a line contains the `--pass` text, 1 when one contains a `--fail` text (which can be given more than once), or 2 if neither arrives within `--timeout` seconds (default 60). `--log FILE` keeps the output for the CI job, and `--junit FILE` writes a JUnit XML report that CI systems show as a test result. With `--remote URL` it runs on a board attached to a remote `haltpoint serve`, so a CI runner can test on a board in the lab ([docs/ci.md](docs/ci.md), with a GitHub Actions example). |
| `haltpoint gdb` | Runs a GDB server on localhost:1337 for `arm-none-eabi-gdb` or VS Code (cortex-debug): `target extended-remote localhost:1337`. Breakpoints use the core's hardware comparators, so they work in flash. `monitor reset` resets and halts. With `--remote URL`, debugs a board on a remote `haltpoint serve` started with `--gdb-listen` ([docs/remote.md](docs/remote.md#gdb)). |
| `haltpoint flash FILE` | Writes an ELF, `.hex` or `.bin` (with `--base 0x08000000`) to flash, verifies it and restarts the target. With a [product manifest](#products-components-and-protected-flash), plain `haltpoint flash` writes every component, and `--component app` just one. |
| `haltpoint identify` | Says what a board is running without stopping it: for each component (or the whole flash), how much is used, its SHA-256, and any version it carries (a version string the manifest points at, an MCUboot image header, a GNU build-id), plus the board's hardware ID. `haltpoint identify build/app.elf` also says whether that file is what's on the board, and exits 1 if not. `--json` for scripts and CI. |
| `haltpoint erase --yes` | Erases the target's whole flash, except protected regions from the manifest (`--force` erases those too). Add `--under-reset` for firmware that blocks the debugger. |
| `haltpoint serve` | Shares this machine's probes over HTTPS with token authentication. `--page` also serves the browser page from `haltpoint ui`, for each person to use with their own token. See [docs/remote.md](docs/remote.md), and [docs/bench-pi.md](docs/bench-pi.md) to run it on a Raspberry Pi from boot. |
| `haltpoint cert bench.local` | Makes the server's TLS certificate and a private CA for clients to trust, without OpenSSL. `--ca-key` signs another server's certificate with the same CA ([docs/remote.md](docs/remote.md#certificates)). |
| `haltpoint ui` | Opens a page in your browser to list probes, run doctor, flash or erase, and watch the RTT output of the running firmware (text channels; use `haltpoint rtt --elf` for defmt), for people who'd rather not use the command line. It only listens on this computer, and the link carries a fresh random token, so other users of the machine and other web pages can't reach the probe through it. |
| `haltpoint fleet` | One line per bench server listed in `fleet.toml`: up or down, its probes, who holds the lease and who is queueing ([docs/remote.md](docs/remote.md#several-servers)). |
| `haltpoint doctor --remote URL` | Runs doctor on a remote `haltpoint serve`. `swo`, `rtt`, `gdb`, `flash` and `erase` take `--remote URL` too (the last two only if the server was started with `--allow-flash` or `--allow-erase`). |
| `haltpoint list` | Lists connected probes, including ones you lack permission to open. |
| `haltpoint chips FILTER` | Searches the built-in chip database. For a chip it doesn't list, add a chip description file with `chip_description` in haltpoint.toml or `--chip-description` ([docs/chips.md](docs/chips.md)). |
| `haltpoint completions bash` | Prints tab completion for bash, zsh, fish, elvish or PowerShell, e.g. `haltpoint completions zsh > ~/.zfunc/_haltpoint`. The Debian package installs completions for bash, zsh and fish, and a man page for each command (`man haltpoint-flash`). |

Every command that talks to a target takes `--probe VID:PID[:SERIAL]` and `--chip NAME`. These
override `haltpoint.toml`. With several probes connected, `doctor` prints the `--probe` value for
each one.

## Production programming

`haltpoint flash` can give each board its own serial number and keep a record of every board
programmed:

```
echo 1000 > serial.txt
haltpoint flash app.elf --serial-at 0x081E0000 --serial-format "HP-{:06}" \
    --serial-counter serial.txt --log boards.csv
```

The serial is written into flash at `--serial-at` in the same pass as the firmware, and verified
with it. Pick an address the firmware doesn't use, such as the last flash sector, and have the
firmware read it from there. `--serial-format u32` (the default) stores four little-endian bytes;
a text format such as `HP-{:06}` stores `HP-001000` and a NUL byte. The counter file only moves on
after a board is verified, so a failed board doesn't use up a number.

`--log` appends one CSV line per board, including failures: UTC time, serial, image, the image's
SHA-256, chip, probe, result, seconds and any error. `--log` also works without a serial.

To program several boards at once, connect one probe per board and add `--all-probes`:

```
haltpoint flash app.elf --all-probes --serial-at 0x081E0000 --serial-format "HP-{:06}" \
    --serial-counter serial.txt --log boards.csv
```

Every board is flashed in parallel and gets the next serial number, with a log line naming its
probe. The summary lists each board as ok or FAILED, and the command exits non-zero if any failed.
In a batch the numbers are claimed before flashing starts, so a board that fails leaves a gap
rather than risking a number being written twice; the log shows which serial it was given. The
probes must have distinct serial numbers, which ST-Link, J-Link and CMSIS-DAP probes normally do.

## Project settings

Haltpoint looks for `haltpoint.toml` in the current directory and its parents, or you can pass
`--config PATH`. Unknown keys are rejected, so typos don't go unnoticed.

```toml
chip = "STM32H753ZI"
probe = "0483:374e"        # VID:PID or VID:PID:SERIAL
speed_khz = 1000           # highest debug clock to use
connect_under_reset = true # hold the target in reset while connecting
```

### Products, components and protected flash

`haltpoint.toml` can also describe the product the board is part of, so the commands know which
firmware goes where and what not to touch:

```toml
[product]
name = "sensor"
# Read from the board before flashing. A board whose ID isn't listed is refused, so rev A
# firmware can't go onto a rev B board. Numbers are little-endian, up to 8 bytes; text
# values ("REV-B") are read up to a NUL.
hardware_id = { address = 0x080E_0000, size = 2, accept = [0x0102, 0x0103] }

[[component]]
name = "bootloader"
file = "boot/build/boot.hex"     # relative to haltpoint.toml
start = 0x0800_0000
size = 0x2_0000

[[component]]
name = "app"
file = "build/app.elf"
start = 0x0802_0000
size = 0xA_0000
version_at = 0x0802_0400         # optional: where the firmware keeps a NUL-terminated version string

# Per-board data, such as serials and calibration, that erase and flash leave alone.
[[protected]]
name = "calibration"
start = 0x080E_0000
size = 0x2_0000
```

- `haltpoint flash` with no file writes every component that has a `file`, in one pass.
  `--component app` writes only that one, and `haltpoint flash other.elf --component app` checks
  that `other.elf` stays inside the app's range. A component's `.bin` goes at its `start`.
- Before anything is erased, haltpoint reads the hardware ID and refuses a board that isn't
  listed, or that has no ID. It also refuses an image that falls outside its component or
  writes into a protected region. `--force` overrides all three, with a warning.
- When the firmware shares a flash sector with a protected region, haltpoint reads the region
  first and writes it back in the same pass, so it is verified along with the firmware. A
  serial number written with `--serial-at` may go into a protected region; the rest of the
  region is kept. `flash --erase-all` and `haltpoint erase` keep every protected region the same
  way. If the region can't be read (a read-protected chip, say), they stop before erasing.
- Components can't overlap each other or a protected region; haltpoint checks the file when it
  reads it.
- A remote server applies its own `haltpoint.toml`, not the client's, and `--component` doesn't
  go through `--remote` yet.

## What doctor checks

- **Probe:** found, permission to open it, not held by another program (OpenOCD, an IDE, a GDB
  server; named on Linux and macOS), and not stuck from an earlier crashed session.
  ST-Link probes are recovered automatically, and very old ST-Link firmware is flagged.
- **Target power:** whether the probe sees a target voltage.
- **Link:** SWD from 4 MHz down to 100 kHz, then JTAG, so a marginal cable shows up as
  "only works at reduced speed" rather than a vague failure.
- **Chip:** identification by auto-detection or `--chip`, connect-under-reset when the running
  firmware gets in the way, and a slower retry when the USB link drops mid-connect.
- **Read protection:** on STM32 F0, F1, F2, F3, F4, F7, G0, G4, L4 and H7, whether flash read
  protection (RDP) is on, which otherwise shows up as flashing failing for no clear reason.

## Logging

Set `RUST_LOG=debug` to see probe-rs's own logging.

## Licence

Licensed under either of [Apache License, Version 2.0](LICENSE-APACHE) or
[MIT license](LICENSE-MIT), at your option.

haltpoint is built on [probe-rs](https://probe.rs) and other open-source libraries, and bundles
chip vendors' flash algorithms. Their licences and copyright notices are in the `licenses`
folder of every download.
