# Haltpoint

Debug probe tooling that tells you **why** your target won't connect, and what to do about it.

```
$ haltpoint doctor
  --  Using settings from /work/blinky/haltpoint.toml
  ok  Probe opened: STLink V3 -- 0483:374e:004600373335510235383531 (ST-LINK)
  --  ST-Link firmware V3J18
  ok  Target powered (3.26 V)
  ok  Debug port responds over SWD at 4000 kHz
WARN  USB link dropped at 4000 kHz, worked when retried at 1000 kHz
       -> If this keeps happening, add `speed_khz = 1000` to haltpoint.toml.
       -> Try a shorter or better USB cable.
  ok  Chip identified: STM32H753ZI (1 core)
```

When something is wrong, it says so in plain words:

```
FAIL  The probe is in use by openocd (pid 30482)
       STLink V3 -- 0483:374e:... is open in another program, so haltpoint can't use it.
       -> Stop that program's debug session or close it, then run haltpoint again.
```

Haltpoint is built on [probe-rs](https://probe.rs), so it works with the probes you already own:
ST-Link, J-Link, CMSIS-DAP (DAPLink, Raspberry Pi Debug Probe, MCU-Link), FTDI and more, on
Linux, macOS and Windows.

> **Status:** early prototype. `doctor`, `erase` and `swo` have been tested on a NUCLEO-H753ZI
> with its on-board ST-Link V3. Other probe and chip combinations should work through probe-rs
> but haven't been tested yet. Reports of what works and what doesn't are very welcome.

## Quick start

1. **Download Haltpoint** from the [releases page](https://github.com/haltpoint/haltpoint/releases):
   one archive each for Linux (x86-64, and arm64 or 32-bit Arm for a Raspberry Pi), macOS (Apple
   silicon or Intel) and Windows. Unpack it and put `haltpoint` on your PATH. On Debian, Ubuntu
   or Raspberry Pi OS, the `.deb` package (`sudo apt install ./haltpoint_*.deb`) also sets up
   USB access for common probes.

   Or **install Rust** from [rustup.rs](https://rustup.rs) and build it yourself:

   ```
   git clone https://github.com/haltpoint/haltpoint
   cd haltpoint
   cargo install --path .
   ```

   On Linux, also install the [probe-rs udev rules](https://probe.rs/docs/getting-started/probe-setup/)
   so you can use probes without root.

2. **Plug in your probe and board**, then check the connection:

   ```
   haltpoint doctor
   ```

   If it can't identify the chip, look up its name and pass it in:

   ```
   haltpoint chips stm32h7
   haltpoint doctor --chip STM32H753ZI
   ```

3. **Save your settings** in a `haltpoint.toml` at the root of your firmware project, so you don't
   have to repeat flags:

   ```toml
   chip = "STM32H753ZI"
   ```

   Doctor will tell you if you need anything else in there, for example a lower speed.

4. **See your firmware's output** over SWO. Pass the core clock your firmware runs at:

   ```
   haltpoint swo --clock-hz 64000000 --self-test   # check the SWO path works
   haltpoint swo --clock-hz 64000000               # print ITM output until Ctrl+C
   ```

## Commands

| Command | What it does |
|---|---|
| `haltpoint doctor` | Checks the probe, target power, the SWD/JTAG link at falling speeds, chip identification and connect-under-reset, then explains what's wrong and how to fix it. Exits with status 1 if anything failed. |
| `haltpoint swo --clock-hz HZ` | Prints what firmware writes to the ITM stimulus ports over SWO: port 0 as text, other ports with a `[port N]` prefix. `--self-test` checks the SWO path with no firmware support. `swo` and `rtt` both take `--timestamps`, `--grep TEXT` to show only matching lines, and `--log FILE` to keep every line. |
| `haltpoint reset` | Resets the target and lets it run; `--halt` stops it at the first instruction and prints where. With `--remote URL` it resets a board on a `haltpoint serve` server (users need the `flash` permission). |
| `haltpoint vscode build/app.elf` | Writes `.vscode/launch.json` and `tasks.json` for the Cortex-Debug extension, so F5 flashes the firmware with haltpoint, starts `haltpoint gdb` and stops at `main`. Works for C, C++ and Rust; `--remote URL` debugs a board on a remote server. Needs `arm-none-eabi-gdb` on the PATH. `--print` shows the files without writing them. |
| `haltpoint rtt` | Prints what firmware writes over SEGGER RTT while it runs, and sends lines you type to down channel 0. `--elf FILE` finds the control block at once instead of searching RAM, and decodes defmt logs (with source lines when the ELF has debug info). With several channels each line is prefixed with its channel's name. With `--remote URL`, reads RTT from a board on a remote `haltpoint serve` ([docs/remote.md](docs/remote.md#rtt)). `testdata/rtt-h753` (C) and `testdata/defmt-h753` (Rust, defmt) are test firmware for the NUCLEO-H753ZI. |
| `haltpoint test app.elf --pass "ALL TESTS PASSED" --fail FAIL` | For CI on real hardware: flashes test firmware, shows its RTT output, and exits 0 when a line contains the `--pass` text, 1 when one contains a `--fail` text (which can be given more than once), or 2 if neither arrives within `--timeout` seconds (default 60). `--log FILE` keeps the output for the CI job, and `--junit FILE` writes a JUnit XML report that CI systems show as a test result. With `--remote URL` it runs on a board attached to a remote `haltpoint serve`, so a CI runner can test on a board in the lab ([docs/ci.md](docs/ci.md), with a GitHub Actions example). On the bench, `haltpoint test testdata/rtt-h753/rtt.elf --pass "tick 3"` passes after about three seconds. |
| `haltpoint gdb` | Runs a GDB server on localhost:1337 for `arm-none-eabi-gdb` or VS Code (cortex-debug): `target extended-remote localhost:1337`. Breakpoints use the core's hardware comparators, so they work in flash. `monitor reset` resets and halts. With `--remote URL`, debugs a board on a remote `haltpoint serve` started with `--gdb-listen` ([docs/remote.md](docs/remote.md#gdb)). |
| `haltpoint flash FILE` | Writes an ELF, `.hex` or `.bin` (with `--base 0x08000000`) to flash, verifies it and restarts the target. `testdata/blink-h753` has a tiny LED blinker for a NUCLEO-H753ZI. |
| `haltpoint erase --yes` | Erases the target's whole flash. Add `--under-reset` for firmware that blocks the debugger. |
| `haltpoint serve` | Shares this machine's probes over HTTPS with token authentication. `--page` also serves the browser page from `haltpoint ui`, for each person to use with their own token. See [docs/remote.md](docs/remote.md), and [docs/bench-pi.md](docs/bench-pi.md) to run it on a Raspberry Pi from boot. |
| `haltpoint cert bench.local` | Makes the server's TLS certificate and a private CA for clients to trust, without OpenSSL. `--ca-key` signs another server's certificate with the same CA ([docs/remote.md](docs/remote.md#certificates)). |
| `haltpoint ui` | Opens a page in your browser to list probes, run doctor, flash or erase, and watch the RTT output of the running firmware (text channels; use `haltpoint rtt --elf` for defmt), for people who'd rather not use the command line. It only listens on this computer, and the link carries a fresh random token, so other users of the machine and other web pages can't reach the probe through it. |
| `haltpoint fleet` | One line per bench server listed in `fleet.toml`: up or down, its probes, who holds the lease and who is queueing ([docs/remote.md](docs/remote.md#several-servers)). |
| `haltpoint doctor --remote URL` | Runs doctor on a remote `haltpoint serve`. `swo`, `rtt`, `gdb`, `flash` and `erase` take `--remote URL` too (the last two only if the server was started with `--allow-flash` or `--allow-erase`). |
| `haltpoint list` | Lists connected probes, including ones you lack permission to open. |
| `haltpoint chips FILTER` | Searches the built-in chip database. |

Every command that talks to a target takes `--probe VID:PID[:SERIAL]` and `--chip NAME`. These
override `haltpoint.toml`. With several probes connected, `doctor` prints the `--probe` value for
each one.

## Production programming

`haltpoint flash` can give each board its own serial number and keep a record of every board
programmed:

```
echo 1000 > serial.txt
haltpoint flash app.elf --serial-at 0x081E0000 --serial-format "HP-{:06}" \
    --serial-counter serial.txt --log boards.csv
```

The serial is written into flash at `--serial-at` in the same pass as the firmware, and verified
with it. Pick an address the firmware doesn't use, such as the last flash sector, and have the
firmware read it from there. `--serial-format u32` (the default) stores four little-endian bytes;
a text format such as `HP-{:06}` stores `HP-001000` and a NUL byte. The counter file only moves on
after a board is verified, so a failed board doesn't use up a number.

`--log` appends one CSV line per board, including failures: UTC time, serial, image, the image's
SHA-256, chip, probe, result, seconds and any error. `--log` also works without a serial.

To program several boards at once, connect one probe per board and add `--all-probes`:

```
haltpoint flash app.elf --all-probes --serial-at 0x081E0000 --serial-format "HP-{:06}" \
    --serial-counter serial.txt --log boards.csv
```

Every board is flashed in parallel and gets the next serial number, with a log line naming its
probe. The summary lists each board as ok or FAILED, and the command exits non-zero if any failed.
In a batch the numbers are claimed before flashing starts, so a board that fails leaves a gap
rather than risking a number being written twice; the log shows which serial it was given. The
probes must have distinct serial numbers, which ST-Link, J-Link and CMSIS-DAP probes normally do.

## Project settings

Haltpoint looks for `haltpoint.toml` in the current directory and its parents, or you can pass
`--config PATH`. Unknown keys are rejected, so typos don't go unnoticed.

```toml
chip = "STM32H753ZI"
probe = "0483:374e"        # VID:PID or VID:PID:SERIAL
speed_khz = 1000           # highest debug clock to use
connect_under_reset = true # hold the target in reset while connecting
```

## What doctor checks

- **Probe:** found, permission to open it, not held by another program (OpenOCD, an IDE, a GDB
  server; named on Linux and macOS), and not stuck from an earlier crashed session.
  ST-Link probes are recovered automatically, and very old ST-Link firmware is flagged.
- **Target power:** whether the probe sees a target voltage.
- **Link:** SWD from 4 MHz down to 100 kHz, then JTAG, so a marginal cable shows up as
  "only works at reduced speed" rather than a vague failure.
- **Chip:** identification by auto-detection or `--chip`, connect-under-reset when the running
  firmware gets in the way, and a slower retry when the USB link drops mid-connect.
- **Read protection:** on STM32 F0, F1, F2, F3, F4, F7, G0, G4, L4 and H7, whether flash read
  protection (RDP) is on, which otherwise shows up as flashing failing for no clear reason.

## Building from source

```
cargo build --release
```

CMSIS-DAP v1 (HID) probes are supported on macOS and Windows by default. On Linux they need
`--features cmsisdap-v1`, which requires the libudev development headers. CMSIS-DAP v2 probes
work everywhere without it, and the Linux release downloads are built without it.

To publish release downloads, push a version tag (`git tag v0.2.0 && git push origin v0.2.0`),
publish a release with a new tag on GitHub's releases page, or run the Release workflow by hand
with the version (`gh workflow run release.yml -f version=v0.2.0`), which tags the commit it
builds. The version must match Cargo.toml's. The
[release workflow](.github/workflows/release.yml) builds every platform and attaches the archives,
plus Debian packages for Linux ([packaging/deb](packaging/deb)), each with a SHA-256 file.

Set `RUST_LOG=debug` to see probe-rs's own logging.

## Licence

Licensed under either of [Apache License, Version 2.0](LICENSE-APACHE) or
[MIT license](LICENSE-MIT), at your option.
