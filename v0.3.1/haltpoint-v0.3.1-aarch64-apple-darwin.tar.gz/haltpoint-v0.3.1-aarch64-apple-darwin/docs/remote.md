# Sharing probes over the network

`haltpoint serve` shares the probes on one machine with other people over HTTPS. Each user has
a token, and the server checks what each token may do (flash, erase, debug) and logs it.

## Getting started

On the bench machine:

```
export HALTPOINT_TOKEN=$(haltpoint token)     # share this with your team securely
haltpoint serve --listen 0.0.0.0:7465 --cert server.pem --key server-key.pem
```

On your machine:

```
export HALTPOINT_TOKEN=...                    # the same token
haltpoint doctor --remote https://bench.local:7465 --remote-ca ca.pem --chip STM32H753ZI
haltpoint flash app.elf --remote https://bench.local:7465 --remote-ca ca.pem --chip STM32H753ZI
haltpoint reset --remote https://bench.local:7465 --remote-ca ca.pem --chip STM32H753ZI
```

Reset needs the `flash` permission, because it interrupts the running firmware, but not
`--allow-flash`, because it leaves the firmware as it is.

For a team, give each person their own token instead of sharing one:

```
haltpoint token --user sam --allow flash,erase   # prints sam's token and a [[user]] entry
haltpoint token --user ci --allow flash
# paste the [[user]] entries into users.toml, then:
haltpoint serve --listen 0.0.0.0:7465 --cert server.pem --key server-key.pem --users users.toml --allow-flash
```

Each person sets HALTPOINT_TOKEN to their own token. The server log names who made each request.
To keep the probe to yourself for a while, for example during a bring-up session:

```
haltpoint lease --remote https://bench.local:7465 --remote-ca ca.pem --minutes 90 --note "rev B bring-up"
haltpoint lease --remote https://bench.local:7465 --remote-ca ca.pem             # who holds it?
haltpoint lease --remote https://bench.local:7465 --remote-ca ca.pem --release
```

While you hold it, others can list probes but everything else, GDB included, is refused with
your name, the end time and the note. Leases end by themselves and last at most 12 hours. They are
kept in memory, so restarting the server clears them.

To wait your turn instead of being refused, add `--wait` with the most minutes you'll wait:

```
haltpoint lease --remote https://bench.local:7465 --remote-ca ca.pem --minutes 15 --wait 30
```

This joins a queue and takes the lease as soon as it's your turn, printing your place while it
waits. When the probe comes free, only the first in the queue can take a lease, so a CI job and a
person waiting for the same board are served in the order they asked. The client asks again every
5 seconds; anyone who hasn't asked for a minute (a cancelled job, a closed laptop) loses their
place. Plain `lease` shows who is queueing.

Add `--audit audit.jsonl` to keep a record on disk: one JSON object per request or GDB session,
with the time, peer, user, action, status, any error, and the SHA-256 of each flashed image.

Flashing needs the server started with `--allow-flash`, and `haltpoint erase --yes --remote URL`
needs `--allow-erase`.

### GDB

Start the server with a second port for GDB, which uses the same certificate and tokens:

```
haltpoint serve --listen 0.0.0.0:7465 --gdb-listen 0.0.0.0:7466 --cert server.pem --key server-key.pem --users users.toml
```

On your machine, `haltpoint gdb --remote` asks the server for its GDB port and listens on
localhost for GDB:

```
haltpoint gdb --remote https://bench.local:7465 --remote-ca ca.pem --chip STM32H753ZI
arm-none-eabi-gdb app.elf -ex "target extended-remote localhost:1337"
```

The user needs `debug` in their `allow` list (`haltpoint token --user sam --allow debug`), since
GDB can read and write any memory. One GDB session holds the probe at a time; flash, erase and
other requests wait up to 90 s and are then refused as busy. If the server can't attach (no
probe, wrong chip), `haltpoint gdb` prints why and keeps waiting for the next GDB connection.

### RTT

The same port carries RTT, so firmware logs from a board on the bench show on your terminal and
lines you type go to the target's down channel 0:

```
haltpoint rtt --remote https://bench.local:7465 --remote-ca ca.pem --chip STM32H753ZI --elf app.elf
```

`--elf` stays on your machine: haltpoint sends the server only the control block's address, and
decodes defmt locally. Any user may read RTT, as with SWO, since it only carries what the
firmware chooses to send. An RTT session holds the probe like a GDB session does.

### SWO

`haltpoint swo --remote URL` without `--seconds` streams SWO through the same port until Ctrl+C,
decoding the ITM packets on your machine:

```
haltpoint swo --remote https://bench.local:7465 --remote-ca ca.pem --chip STM32H753ZI --clock-hz 64000000
```

With `--seconds` (at most 60) or `--self-test` it uses the fixed capture over HTTP instead,
which works on servers started without `--gdb-listen`.

### Hardware tests from CI

`haltpoint test --remote` flashes test firmware through the server, then watches its RTT
output through the tunnel for a pass or fail line, exiting 0, 1 or 2 like a local run:

```
haltpoint test build/tests.elf --remote https://bench.local:7465 --remote-ca ca.pem \
    --pass "ALL TESTS PASSED" --fail FAIL --timeout 120 --junit results.xml
```

The server needs `--allow-flash` and `--gdb-listen`, and the CI job's user needs `flash` in
its `allow` list. Take a lease first (`haltpoint lease --minutes 10`) so no one else flashes
the board between the two steps.

### In a browser

Start the server with `--page` and it also serves the page `haltpoint ui` shows, at
`https://bench.local:7465/`. Each person opens it and types their own token, or opens a link with
the token after a `#` (`https://bench.local:7465/#TOKEN`), which the browser never sends to the
server. The page keeps the token for that tab only, and takes it out of the address bar. It
lists the probes, runs doctor, flashes, resets, shows the live RTT log and, when the server
allows it and the user may, erases. When someone holds a lease, the page says who and until when.

The browser has to trust the certificate: install `ca.pem` as a trusted authority on each
machine, or the browser warns before every visit.

### Several servers

With more than one bench, list them in a `fleet.toml`:

```toml
[[server]]
name = "bench-1"
url = "https://bench-1.local:7465"
ca = "ca.pem"                  # relative to this file

[[server]]
name = "ci-rack"
url = "https://rack.local:7465"
ca = "rack-ca.pem"
token_env = "RACK_TOKEN"       # default HALTPOINT_TOKEN
```

`haltpoint fleet` (or `haltpoint fleet path/to/fleet.toml`) asks them all at once and prints a
line each:

```
bench-1  up      STLink V3; held by ci until 2026-10-17T09:00:00Z, 1 queueing
ci-rack  up      probe busy; free
lab-pi   DOWN    couldn't reach https://lab-pi.local:7465/v1/lease: Connection refused
```

"probe busy" means the server answered but its probe is in use, usually by a GDB session. The
command exits non-zero if any server is down, so it can run as a monitoring check.
`haltpoint fleet --watch 30` keeps the table on screen, checking every 30 seconds, and lists
the last few servers that went down or came back, with the time.

### Certificates

The certificate must be issued by a CA, which can be your own. A self-signed certificate that is
its own CA is rejected by the client's TLS library. `haltpoint cert` makes a private CA and a
server certificate, with every name and address clients will use:

```
haltpoint cert bench.local 192.168.1.20 --out certs
```

That writes `ca.pem` (for clients), `ca-key.pem` (keep it safe, off the server), and
`server.pem` and `server-key.pem` (for the server), valid for 825 days. For a second server
that the same `ca.pem` trusts:

```
haltpoint cert bench-2.local --out certs-2 --ca-key certs/ca-key.pem
```

Or with OpenSSL:

```
openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes -keyout ca-key.pem -out ca.pem -days 365 -subj "/CN=Bench CA"
openssl req -newkey ec -pkeyopt ec_paramgen_curve:P-256 -nodes -keyout server-key.pem -out server.csr -subj "/CN=bench.local"
printf "subjectAltName=DNS:bench.local\nbasicConstraints=CA:FALSE\n" > ext.cnf
openssl x509 -req -in server.csr -CA ca.pem -CAkey ca-key.pem -CAcreateserial -out server.pem -days 365 -extfile ext.cnf
```

## API (v1)

All requests carry `Authorization: Bearer <token>`. All responses are JSON.

| Method and path | Body | Response |
|---|---|---|
| `GET /v1/probes` | none | `[{"name": "...", "selector": "0483:374e:..."}]` |
| `POST /v1/doctor` | `{"probe": "VID:PID[:SERIAL]"?, "chip": "NAME"?}` | The findings `doctor` prints, as a list of `{severity, title, detail, fixes}` |
| `POST /v1/flash?format=elf\|hex\|bin&base=ADDR&chip=NAME&probe=SEL` | The raw image, up to 16 MiB. `base` only with `bin`; `chip` and `probe` are optional and default to the server's haltpoint.toml. | `{"bytes": N, "seconds": S}` once the image is written, verified and the target restarted |
| `POST /v1/swo` | `{"probe": ...?, "chip": ...?, "clock_hz": N, "baud": N, "seconds": 1-60, "self_test": false}` | `{"output": "...", "overflows": N}`: what arrived, formatted as `haltpoint swo` prints it |
| `POST /v1/reset` | `{"probe": ...?, "chip": ...?, "halt": false}`; needs the `flash` permission | `{"pc": N}` with `halt`, else `{"pc": null}` |
| `POST /v1/rtt?chip=NAME&probe=SEL` | none | Stays open while the target runs: newline-separated JSON, first `{"start": {"address", "channels": [{"number", "name"}]}}`, then `{"channel", "text"}` lines, or a last `{"error"}`, with a blank line every 2 s when idle. Holds the probe until the client closes it. |
| `POST /v1/erase` | `{"probe": ...?, "chip": ...?, "under_reset": false}` | `{"seconds": S}` once the whole flash is blank |
| `POST /v1/lease` | `{"minutes": N?, "note": "..."?, "queue": bool?}`: none reports, 0 releases, more takes or extends; `queue` joins or keeps a place in the queue when refused | `{"holder", "until", "note", "waiting"}`, or 423 if someone else holds it or is ahead in the queue |
| `GET /v1/gdb` | none | `{"port": N}`: the GDB and RTT tunnel port, or 404 if the server has none |

Errors are `{"error": "..."}` with status 400 (bad request), 401 (token), 403 (flashing or
erasing not allowed), 404 (unknown path), 409 (the probe stayed busy for 90 s, usually with a GDB
session), 423 (someone else holds a lease) or 413 (body too large).

The tunnel port speaks TLS (when the server has a certificate). The client sends one line,
`HALTPOINT-GDB/1 <token> <chip or -> <probe or ->` with each field percent-encoded, or for RTT
`HALTPOINT-RTT/1 <token> <chip or -> <probe or -> <control block address or ->`, or for SWO
`HALTPOINT-SWO/1 <token> <chip or -> <probe or -> <clock Hz> <baud>`. The server
answers `OK` once it has opened the target, or `ERR <reason>` and closes.

After `OK`, a GDB connection carries GDB's remote serial protocol unchanged. An RTT connection
starts with one line from the server, `RTT <address> <number>:<name> ...` (names
percent-encoded, `-` for none), then frames of one byte channel number, two bytes little-endian
length and the data. Channel 255 carries the error that ended the session. The client sends raw
bytes for down channel 0. An SWO connection carries the raw trace bytes as frames on channel 0,
with the same error channel; the client sends nothing.
