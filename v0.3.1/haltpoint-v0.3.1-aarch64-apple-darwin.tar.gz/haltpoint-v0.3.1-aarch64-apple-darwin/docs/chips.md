# Chips that aren't in the built-in list

`haltpoint chips FILTER` searches probe-rs's built-in list, which covers most parts from ST, Nordic,
NXP, Microchip, Espressif, Raspberry Pi and others. For a part it doesn't have (a new release, a
custom ASIC, a vendor's less common family), give haltpoint a chip description: a YAML file in
probe-rs's target format.

## Getting a description

- **From the vendor's CMSIS-Pack** (most Arm parts have one, at
  [keil.arm.com/packs](https://www.keil.arm.com/packs/)): probe-rs's `target-gen` tool, in the
  [probe-rs repository](https://github.com/probe-rs/probe-rs/tree/master/target-gen), turns the
  `.pack` file into a description with the flash algorithm included (its `pack` command).

- **By hand**, starting from a similar chip in
  [probe-rs's targets folder](https://github.com/probe-rs/probe-rs/tree/master/probe-rs/targets).
  [testdata/custom-chip/acme.yaml](../testdata/custom-chip/acme.yaml) is a minimal example: one
  Cortex-M4 core, flash and RAM. Without a flash algorithm, doctor, reset, RTT, SWO and GDB work,
  but `haltpoint flash` can't program it.

## Using it

Name the file in `haltpoint.toml` (the path is relative to that file), then use the chip's name
as usual:

```toml
chip = "ACME_M4_256K"
chip_description = "chips/acme.yaml"
```

Or pass `--chip-description FILE` to any command. `haltpoint chips` then lists the new chips
alongside the built-in ones.

For a board on a bench server, the description goes on the server: put `chip_description` in the
server's settings file (for the Debian package, `/etc/haltpoint/haltpoint.toml`), since the server
is the one that connects to the chip. Clients only send the chip's name.
