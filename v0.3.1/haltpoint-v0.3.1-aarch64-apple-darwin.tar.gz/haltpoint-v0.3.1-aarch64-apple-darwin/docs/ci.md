# Hardware tests in CI

`haltpoint test` runs test firmware on a real board and turns what it prints into a pass or a
fail that CI understands. With a board on a lab bench served by `haltpoint serve`, any CI job
can use it.

## How it works

1. The firmware's tests run on the target and report over RTT or a UART. The last thing they print is a
   line containing a pass text (for example `ALL TESTS PASSED`), or a fail text as soon as a
   test fails. Any test framework works, as long as it prints such lines.
2. `haltpoint test` flashes the firmware, watches RTT (or the serial port given with `--uart`),
   and exits 0 if it passed, 1 if it failed, or 2 if neither line came before `--timeout`.
3. `--junit FILE` writes a JUnit XML report, with the firmware's output attached, which GitHub,
   GitLab and Jenkins show as a test result. `--log FILE` keeps the output as plain text.

Locally, with the board on USB:

```
haltpoint test build/tests.elf --pass "ALL TESTS PASSED" --fail FAIL
```

Firmware that logs over a UART instead, through a USB serial adapter or the probe's own virtual
COM port:

```
haltpoint test build/tests.elf --uart /dev/ttyACM0 --baud 115200 --pass "ALL TESTS PASSED" --fail FAIL
```

The port is opened before flashing. Once the new firmware is verified, haltpoint drops whatever
the port received up to then (such as the previous firmware's verdict), restarts the target and
watches from its first line. `--uart` works on a board attached to the machine running the
command; it doesn't go through `--remote` yet.

## A board in the lab

On a Raspberry Pi (or any small Linux machine) with the board attached, run `haltpoint serve`
with `--allow-flash` and `--gdb-listen`, a TLS certificate, and a users file, as
[remote.md](remote.md) describes; [bench-pi.md](bench-pi.md) sets this up as a service that
starts at boot. Give CI its own user:

```
haltpoint token --user ci --allow flash
```

Then from anywhere that can reach the Pi:

```
HALTPOINT_TOKEN=... haltpoint test build/tests.elf --remote https://bench.local:7465 \
    --remote-ca ca.pem --pass "ALL TESTS PASSED" --fail FAIL --junit results.xml
```

## GitHub Actions

[examples/github-actions/hardware-tests.yml](../examples/github-actions/hardware-tests.yml) is a
complete workflow to copy. Before it runs your tests, it books the board with a lease, so a
person can't flash it between the flash and the test steps. It gives the board back
afterwards, even if the tests fail, and it keeps the JUnit report and the output.

Runs of this workflow queue on one board through its `concurrency` group. If a person or
another repository has the board, `lease --wait 30` queues for it, first come first served,
instead of failing the run. The example uses a
self-hosted runner on the lab network, so the bench never needs to be reachable from the
internet.
