# Setting up a bench Raspberry Pi

This turns a Raspberry Pi (or any Linux machine) next to your boards into a permanent
`haltpoint serve` server: it starts at boot, restarts if it stops, and keeps an audit log. It takes
about fifteen minutes. [remote.md](remote.md) explains what the server does and how clients use it.

A Pi 3, 4, 5 or Zero 2 W running Raspberry Pi OS bookworm or later works. The original Pi Zero
and Pi 1 (ARMv6) aren't supported by the release downloads.

## 1. Install haltpoint

The easy way is the Debian package, which also does steps 2 and 4: it installs the service and
udev rules for common probes, and creates the server's user. Pick `arm64` (64-bit OS, `uname -m`
says `aarch64`) or `armhf` (32-bit OS, `armv7l`) from the
[downloads page](https://github.com/haltpoint/downloads):

```
VERSION=0.3.0
ARCH=arm64                            # or armhf
curl -LO https://github.com/haltpoint/downloads/raw/main/v$VERSION/haltpoint_${VERSION}_$ARCH.deb
sudo apt install ./haltpoint_${VERSION}_$ARCH.deb
haltpoint --version
```

Then go on to step 3; in step 4, skip downloading the unit, as it's already installed.
The package doesn't start the server, because it needs the certificate and users first.
Upgrading is the same `apt install` of the newer package, which restarts the server if it's
running. (Packages are published from v0.2.0 on.)

Or install the plain binary. Pick the download that matches `uname -m`: `aarch64` (64-bit OS) or
`armv7l` (32-bit OS). From the [downloads page](https://github.com/haltpoint/downloads),
for example:

```
VERSION=v0.3.0
TARGET=aarch64-unknown-linux-gnu      # or armv7-unknown-linux-gnueabihf
curl -LO https://github.com/haltpoint/downloads/raw/main/$VERSION/haltpoint-$VERSION-$TARGET.tar.gz
curl -LO https://github.com/haltpoint/downloads/raw/main/$VERSION/haltpoint-$VERSION-$TARGET.tar.gz.sha256
sha256sum -c haltpoint-$VERSION-$TARGET.tar.gz.sha256
tar xzf haltpoint-$VERSION-$TARGET.tar.gz
sudo install haltpoint-$VERSION-$TARGET/haltpoint /usr/local/bin/
haltpoint --version
```

## 2. Let it use USB probes

*(The Debian package does this step.)* Install the [probe-rs udev rules](https://probe.rs/docs/getting-started/probe-setup/), which give
the `plugdev` group access to debug probes, then create a user for the server:

```
sudo useradd --system --no-create-home --groups plugdev haltpoint
```

Plug in the probe and check it's seen: `sudo -u haltpoint haltpoint list`.

## 3. Settings

Everything the server reads lives in `/etc/haltpoint`:

```
sudo mkdir -p /etc/haltpoint
cd /etc/haltpoint
```

- **Certificate.** On your own machine, run `haltpoint cert bench.local --out bench-certs`
  with the Pi's name (add its IP address too if clients use that), then copy `server.pem` and
  `server-key.pem` from `bench-certs` to `/etc/haltpoint` on the Pi. Clients get `ca.pem`;
  `ca-key.pem` stays on your machine, somewhere safe, for certificates for more Pis
  ([remote.md](remote.md#certificates)).
- **Users.** Run `haltpoint token --user NAME --allow flash` for each person or CI job, give each
  token to its owner, and put the printed `[[user]]` entries in `users.toml`. Add `debug` for GDB,
  and `erase` only if you also add `--allow-erase` to the service.
- **Board defaults (optional).** A `haltpoint.toml` here sets the chip, probe and speed for
  clients that don't name them:

  ```toml
  chip = "STM32H753ZI"
  ```

  For a chip probe-rs doesn't list, put its description here too, with `chip_description`
  ([chips.md](chips.md)).

Only the server needs to read these:

```
sudo chown -R root:haltpoint /etc/haltpoint
sudo chmod 640 /etc/haltpoint/*
sudo chmod 750 /etc/haltpoint
```

## 4. Start it at boot

With the plain binary, install the unit from the archive first (the Debian package already
has):

```
sudo install -m 644 haltpoint-$VERSION-$TARGET/examples/systemd/haltpoint.service \
    /etc/systemd/system/
sudo systemctl daemon-reload
```

Then, either way:

```
sudo systemctl enable --now haltpoint
systemctl status haltpoint
```

[The unit](../examples/systemd/haltpoint.service) listens on 7465 for requests and 7466 for GDB,
allows flashing, writes the audit log to `/var/lib/haltpoint/audit.jsonl`, and can't write
anywhere else. To change any of that, for example to add `--page` for the
[browser page](remote.md#in-a-browser), run `sudo systemctl edit haltpoint` and give a new
`ExecStart` (an override survives package upgrades):

```
[Service]
ExecStart=
ExecStart=/usr/bin/haltpoint serve --listen 0.0.0.0:7465 --gdb-listen 0.0.0.0:7466 \
    --cert /etc/haltpoint/server.pem --key /etc/haltpoint/server-key.pem \
    --users /etc/haltpoint/users.toml --audit /var/lib/haltpoint/audit.jsonl --allow-flash --page
```

then `sudo systemctl restart haltpoint`. With the plain binary, the path is
`/usr/local/bin/haltpoint`.

The server's own log, one line per request with who made it, is in the journal:

```
journalctl -u haltpoint -f
```

## 5. Check it from your machine

```
export HALTPOINT_TOKEN=...            # your token from step 3
haltpoint doctor --remote https://bench.local:7465 --remote-ca ca.pem
```

`doctor` should report the probe and the board. If it can't connect, check the Pi's firewall
allows ports 7465 and 7466, and that the name you use matches the certificate.

## Upgrading

With the Debian package, `sudo apt install` the new one. Otherwise install the new binary as in
step 1, then `sudo systemctl restart haltpoint`. Leases and the
lease queue are kept in memory, so a restart clears them; the audit log is kept.
